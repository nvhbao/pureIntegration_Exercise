package jsonexercise.demo;

import jsonexercise.demo.controller.ExerciseController;
import jsonexercise.demo.model.DataModel;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.*;

public class TestController {

  @Test
  void getAll() {
    ExerciseController exerciseController = new ExerciseController();
    DataModel dataModel = exerciseController.getAll();

    assertEquals("success",dataModel.getStatus());
  }
}
