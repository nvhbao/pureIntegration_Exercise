package jsonexercise.demo.model;

import javax.xml.crypto.Data;

public class Message {
  private DataModel dataModel;
  private String status;

  public Message() {
  }

  public DataModel getDataModel() {
    return dataModel;
  }

  public void setDataModel(DataModel dataModel) {
    this.dataModel = dataModel;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }
}
