package jsonexercise.demo.controller;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jsonexercise.demo.model.DataModel;
import jsonexercise.demo.model.Message;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/breeds/")
public class ExerciseController {

  @GetMapping("/list/all")
  public DataModel  getAll() {
    String pathFileName;
    pathFileName = "/static/apidata.json.txt";

    //DataModel breeds = parseJsonObject(pathFileName);
    DataModel breeds = new DataModel();
    if (breeds != null) {
      Map<String, List<String>> message = new HashMap<String, List<String>>();

      //For testing only
      message.put("wolfhound", Arrays.asList("irish"));
      message.put("whippet", Arrays.asList(""));

      breeds.setMessage(message);
      breeds.setStatus("success");


    }

    return breeds;
  }

  public DataModel parseJsonObject(String pathFileName) {
    ObjectMapper objectMapper = new ObjectMapper();
    TypeReference<DataModel> typeReference = new TypeReference<DataModel>(){};
    InputStream inputStream = TypeReference.class.getResourceAsStream(pathFileName);
    try {
        return objectMapper.readValue(inputStream, typeReference);
    } catch (IOException e) {
      e.printStackTrace();
    }

    return null;
  }

}
